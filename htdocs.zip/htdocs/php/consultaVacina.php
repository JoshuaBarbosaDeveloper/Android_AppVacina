<?php

include "conexao.php";

try {

    $id = $_POST["id"];

    $sql = "SELECT * FROM vacinas WHERE id = '".$id."'";
    //SELECT * FROM usuarios WHERE id = '1'

    $statement = $PDO->prepare($sql);
    $statement->execute();
    
    if ($statement->rowCount() > 0) {
        $retornoBD = $statement->fetch();
        $resposta["erro"] = false;
        $resposta["mensagem"] = "ID encontrado no banco de dados";
        $resposta["nome"] = $retornoBD["nomeVacina"];
		$resposta["laboratorio"] = $retornoBD["laboratorioVacina"];
		$resposta["pais"] = $retornoBD["paisVacina"];

    } else {
        $resposta["erro"] = true;
        $resposta["mensagem"] = "ID Não encontrado";
    }


} catch (PDOException $e) {

    $resposta["erro"] = true;
    $resposta["mensagem"] = $e;

}

echo json_encode($resposta);

?>