<?php

$dsn = "mysql:host=localhost;dbname=db_vacinas;charset=utf8";
$usuario = "root";
$senha = "";

try {

    $PDO = new PDO($dsn, $usuario, $senha);
    $PDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "Conectamos!";

} catch (PDOException $e) {

    echo "Deu erro: " . $e;

}




?>