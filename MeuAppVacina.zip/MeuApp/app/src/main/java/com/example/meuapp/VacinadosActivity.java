package com.example.meuapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class VacinadosActivity extends AppCompatActivity {

    String EXTRA_MESSAGE = "com.example.meuapp.MESSAGE";
    VacinadosAdapter adaptador;
    List<Vacinados> vacinados;
    ListView lvVacinados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_lista);

        vacinados = new ArrayList<>();
        vacinados.add(new Vacinados("Anderson da Silva"));
        vacinados.add(new Vacinados("Cláudia Ramos"));
        vacinados.add(new Vacinados("José de Oliveira"));

        adaptador = new VacinadosAdapter(this, vacinados);

        lvVacinados = findViewById(R.id.lvVacinados);

        lvVacinados.setAdapter(adaptador);

        lvVacinados.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent(getApplicationContext(), VacinadosActivity.class);
                Vacinados vacinadosoClicado = vacinados.get(position);
                i.putExtra(EXTRA_MESSAGE, vacinadosoClicado);
                startActivity(i);
            }


        });

    }
}
