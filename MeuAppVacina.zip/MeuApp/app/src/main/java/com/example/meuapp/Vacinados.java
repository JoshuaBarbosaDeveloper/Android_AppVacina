package com.example.meuapp;

import java.io.Serializable;

public class Vacinados implements Serializable {

    String nome;

    public Vacinados(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

}
