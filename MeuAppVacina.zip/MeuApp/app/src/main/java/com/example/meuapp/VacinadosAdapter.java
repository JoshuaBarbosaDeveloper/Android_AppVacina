package com.example.meuapp;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class VacinadosAdapter extends BaseAdapter {

    Activity act;
    List<Vacinados> vacinados;

    public VacinadosAdapter(Activity act, List<Vacinados> vacinados) {
        this.act = act;
        this.vacinados = vacinados;
    }

    @Override
    public int getCount() {
        return vacinados.size();
    }

    @Override
    public Object getItem(int position) {
        return vacinados.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view;
        view = act.getLayoutInflater().inflate(R.layout.item_lista_vacinados, parent, false);

        TextView tvNome = view.findViewById(R.id.tvNomePessoa);
        tvNome.setText(vacinados.get(position).getNome());



        return view;
    }
}
