package com.example.meuapp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

public class RequestHandler {

    //Este método irá enviar informações via método POST para uma URL informada.
    //Utilizaremos o HashMap para definir os campos e os valores transmitidos via POST.
    public String enviarPost(String URLDestino, HashMap<String, String> dados) {
        URL url;

        StringBuilder sb = new StringBuilder();
        try {
            url = new URL(URLDestino);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(15000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("POST");
            conn.setDoInput(true);
            conn.setDoOutput(true);

            OutputStream os = conn.getOutputStream();

            BufferedWriter writer = new BufferedWriter(
                    new OutputStreamWriter(os, "UTF-8"));
            // Chamamos uma função auxiliar para colcoar nossos dados no formato necessário para enviar o POST.
            writer.write(formatarDadosParaPost(dados));

            writer.flush();
            writer.close();
            os.close();
            int responseCode = conn.getResponseCode();

            if (responseCode == HttpsURLConnection.HTTP_OK) {

                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                sb = new StringBuilder();
                String resposta;

                while ((resposta = br.readLine()) != null) {
                    sb.append(resposta);
                }
            } else {
                sb.append("URL Não encontrada.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return sb.toString();
    }


    //this method is converting keyvalue pairs data into a query string as needed to send to the server
    private String formatarDadosParaPost(HashMap<String, String> dados) throws UnsupportedEncodingException {
        StringBuilder dadosFormatados = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : dados.entrySet()) {
            if (first) {
                first = false;
            } else {
                dadosFormatados.append("&");
            }

            dadosFormatados.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            dadosFormatados.append("=");
            dadosFormatados.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }

        return dadosFormatados.toString();
    }
}
