package com.example.meuapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class ConsultarVacinaActivity extends AppCompatActivity {

    public static String host = "http://10.1.1.124/php/";

    EditText etId;
    TextView tvLab, tvNome, tvPais;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_vacina);
        // Capura a intente criada e a mensagem enviada
        Intent intent = getIntent();

        tvNome = findViewById(R.id.tvNome);
        tvLab = findViewById(R.id.tvLab);
        tvPais = findViewById(R.id.tvPais);
        etId = findViewById(R.id.etId);

        Button btBuscarCodigo = (Button) findViewById(R.id.btBuscarCodigo);

        btBuscarCodigo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                final String URL = ConsultarVacinaActivity.host + "consultaVacina.php";
                final String id = etId.getText().toString();


                new AsyncTask<Void, Void, String>() {
                    ProgressDialog pdLoading = new ProgressDialog(ConsultarVacinaActivity.this);

                    @Override
                    protected void onPreExecute() {
                        super.onPreExecute();

                        pdLoading.setMessage("Buscando vacina no banco de dados...");
                        pdLoading.setCancelable(false);
                        pdLoading.show();
                    }

                    @Override
                    protected String doInBackground(Void... voids) {

                        // Criar um objeto para converter dados para post
                        RequestHandler rh = new RequestHandler();

                        // Colocar informações a serem enviadas no POST
                        HashMap<String, String> dados = new HashMap();
                        dados.put("id", id);

                        // Obter Respota do PHP
                        String resposta = rh.enviarPost(URL, dados);

                        return resposta;
                    }

                    @Override
                    protected void onPostExecute(String s) {
                        super.onPostExecute(s);
                        // Esconder tela de autenticando
                        pdLoading.dismiss();

                        try {
                            JSONObject resposta = new JSONObject(s);

                            if (resposta.getBoolean("erro") == true ) {

                                Toast.makeText(getApplicationContext(), "ERRO", Toast.LENGTH_LONG).show();

                            } else {
                                // Tratar Resultado.
                                tvNome.setText(resposta.getString("nome"));
                                tvLab.setText(resposta.getString("laboratorio"));
                                tvPais.setText(resposta.getString("pais"));

                            }



                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                        //Mostrar Resposta do PHP


                    }


                }.execute();

            }
        });
    }


}
